#ifndef __CODEGEN_H___
#define __CODEGEN_H___
#include <stdio.h>

extern void codeStart(struct nodeType *node,FILE* ptr);
//extern int curlevel;


#include "node.h"



#endif