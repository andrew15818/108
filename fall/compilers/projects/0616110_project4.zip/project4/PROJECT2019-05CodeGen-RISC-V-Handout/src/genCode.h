#include "node.h"
void genCode(struct nodeType* node);
void emitPrepareMain();
void emitFunctionPrelude();
void emitFunction(const char* function_Name);
void openFile();

