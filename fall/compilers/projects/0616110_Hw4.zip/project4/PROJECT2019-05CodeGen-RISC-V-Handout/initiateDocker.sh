#!/bin/bash
sudo docker run -it -v $(pwd):/mnt qooqoo/riscv_qemu /bin/bash
